0.10 "la rosa de foc"
+++++++++++++++++++++++++++++++++++++

We are pleased to announce the Bitmask 0.10 release, codename "la rosa de foc".
You can refer to `the changelog`_ for the whole changeset.

This is still a beta-only release of the Encrypted Email service, that ships
again with the Pixelated email user agent. We have also ported the VPN service
from the legacy 0.9.2 bitmask client. This is the first release of the new
codebase that ships VPN, so expect some rough behavior.

The demo provider for the Mail service you should use with this bundle is 
https://mail.bitmask.net. For VPN, you can keep using https://demo.bitmask.net

Please help us making Bitmask better, by testing it and filing any bug reports
in the new issue tracker: https://0xacab.org/leap/bitmask-dev/issues, 

Until the next release, see you on the intertubes, and stay safe.

The Bitmask team.

.. _`the changelog`: https://0xacab.org/leap/bitmask-dev/blob/0.10rc2/docs/changelog.rst
